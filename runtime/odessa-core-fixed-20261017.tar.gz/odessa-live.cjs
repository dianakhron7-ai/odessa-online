// ODESSA_TEXT_CLEAN_V1
// ODESSA_RADAR_EXPIRY_24H_V1
const radarExpiry=require('./odessa-radar-expiry.cjs').create(__dirname);
const fs=require('fs'),path=require('path');
const {run:baseRun}=require('./odessa-live-bridge.cjs');
// ODESSA_LIVE_EDIT_SYNC_V1
const editSync=require('./odessa-live-edit-sync.cjs').create(__dirname,baseRun);
const run=input=>editSync.run(input);
const STATE=path.join(__dirname,'odessa-live-state.json'),LOCK=path.join(__dirname,'odessa-live.lock');
const preview=process.argv.includes('--preview'),prepare=process.argv.includes('--prepare'),once=process.argv.includes('--once'),dry=process.argv.includes('--dry-run');
function save(s){fs.writeFileSync(STATE+'.tmp',JSON.stringify(s));fs.renameSync(STATE+'.tmp',STATE);}
async function main(){
  // ODESSA_FULL_ORTHOGRAPHY_V1
  const {proofreadItems}=await import('./odessa-proofread.mjs');
  const {cleanRadarItems}=await import('./odessa-text-clean.mjs');
  const {CHANNEL,parse,skipCollection,isAlertPost}=await import('./odessa-live-policy.mjs');
  const mediaSupport=require('./odessa-live-media.cjs').create(__dirname,parse,CHANNEL);
  let state=fs.existsSync(STATE)?JSON.parse(fs.readFileSync(STATE,'utf8')):{};
  async function page(before){const r=await fetch('https://t.me/s/'+CHANNEL+(before?'?before='+before:''),{signal:AbortSignal.timeout(20000)});if(!r.ok)throw Error('HTTP '+r.status);if(new URL(r.url).pathname!=='/s/'+CHANNEL)throw Error('Публичная страница недоступна');return cleanRadarItems(await proofreadItems(parse(await r.text())));}
  do{try{
    let items=await page(),latest=items.at(-1).id;
    if(preview){console.log('Канал Одесса LIVE доступен. Последний пост:',latest);for(const x of items.slice(-3))console.log(JSON.stringify({id:x.id,date:new Date(x.date).toISOString(),text:x.text,photos:x.images.length,videos:(x.media||[]).filter(m=>m.type==='video').length,unsupported:x.unsupported}));return;}
    if(dry){const x=items.filter(i=>!skipCollection(i.text)&&isAlertPost(i.text)&&!i.unsupported&&(i.text||i.media?.length||i.images.length)).at(-1);if(!x)throw Error('Нет доступного поста для проверки');console.log('Проверка без публикации в группе');await run({channel:CHANNEL,items:[x],dryRun:true});return;}
    if(prepare||state.channel!==CHANNEL||!Number.isInteger(state.id)){state={id:latest,channel:CHANNEL};save(state);console.log('Радар подключён к '+CHANNEL+'. Старые посты пропущены:',latest);if(prepare)return;}
    else{
      if(latest<state.id)throw Error('Номер поста уменьшился; состояние сохранено');
      for(let n=0;n<50&&items[0].id>state.id;n++){const old=await page(items[0].id);if(old[0].id>=items[0].id)break;items=[...new Map([...old,...items].map(x=>[x.id,x])).values()].sort((a,b)=>a.id-b.id);}
      if(items[0].id>state.id+1)throw Error('Большой пропуск ленты; требуется проверка');
      for(let item of items){if(item.id<=state.id)continue;if(skipCollection(item.text)){state={id:item.id,channel:CHANNEL};save(state);console.log('Пропущен сбор/реклама/вопрос:',item.id);continue;}if(!isAlertPost(item.text)){state={id:item.id,channel:CHANNEL};save(state);console.log('Пропущен нерадарный пост:',item.id,JSON.stringify(item.text).slice(0,600));continue;}item=await mediaSupport.hydrate(item);if(item.unsupported){mediaSupport.pending(item,'MEDIA_UNAVAILABLE: публичная страница не отдаёт файл');state={id:item.id,channel:CHANNEL};save(state);continue;}try{await run({channel:CHANNEL,items:[item]});}catch(error){if(!String(error.message).startsWith('MEDIA_UNAVAILABLE:'))throw error;mediaSupport.pending(item,error.message);state={id:item.id,channel:CHANNEL};save(state);continue;}state={id:item.id,channel:CHANNEL};save(state);console.log('Радар обработан:',item.id,JSON.stringify(item.text).slice(0,600));}
    }
    if(!preview&&!dry&&!prepare)await editSync.sync(items,state.id,item=>!skipCollection(item.text)&&isAlertPost(item.text));
  }catch(e){console.error(new Date().toISOString(),e.message);if(once||prepare||dry||preview){process.exitCode=1;return;}}
  if(!preview&&!dry&&!prepare){try{radarExpiry.tick();}catch(e){console.error('Радар: ошибка очистки:',e.message);}}
  if(once)return;await new Promise(r=>setTimeout(r,5000));}while(true);
}
try{
  try{fs.writeFileSync(LOCK,String(process.pid),{flag:'wx'});}catch(e){if(e.code!=='EEXIST')throw e;const pid=Number(fs.readFileSync(LOCK,'utf8'));if(!Number.isInteger(pid)||pid<1)throw Error('Неверный lock-файл');let alive=false;try{process.kill(pid,0);alive=true;}catch{}if(alive)throw Error('Обработчик Одесса LIVE уже запущен');fs.unlinkSync(LOCK);fs.writeFileSync(LOCK,String(process.pid),{flag:'wx'});}
  process.on('exit',()=>{try{if(fs.readFileSync(LOCK,'utf8')===String(process.pid))fs.unlinkSync(LOCK);}catch{}});
  process.on('SIGTERM',()=>process.exit(0));process.on('SIGINT',()=>process.exit(0));
  main().catch(e=>{console.error(e.message);process.exitCode=1;});
}catch(e){console.error(e.message);process.exitCode=1;}

// ODESSA_EXACT_COPY_V1
