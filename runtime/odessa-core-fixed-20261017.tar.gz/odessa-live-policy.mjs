import {radarOperational} from './odessa-radar-filter.mjs';
import {decode,safePhoto} from './odessa-source-policy.mjs';
export const CHANNEL='odessagolovna';

const STRICT_NON_RADAR=/(реклам|промокод|розіграш|розыгрыш|підписуй|подписыв|партнер|спонсор|збір\s*(?:коштів|грошей)|сбор\s*(?:средств|денег)|донат|monobank|privat24|paypal|банка|банку|опитуван|опрос|підкажіть|подскажите|ваша\s+думка|ваше\s+мнение|хто\s+знає|кто\s+знает|новин|новост|дтп|поліці|полици|суд|затриман|задержан|загин|погиб|поран|ранен|наслідк|последств|пошкоджен|поврежден|дснс)/i;
// ODESSA_EXACT_COPY_V1
function exactDecode(raw){return String(raw||'').replace(/&#(x[0-9a-f]+|\d+);/gi,(_,v)=>{const n=v[0].toLowerCase()==='x'?parseInt(v.slice(1),16):Number(v);return n>0&&n<=0x10ffff?String.fromCodePoint(n):'';}).replace(/&(nbsp|quot|apos|lt|gt|amp);/g,(_,v)=>({nbsp:' ',quot:'"',apos:"'",lt:'<',gt:'>',amp:'&'}[v]));}
function exactAttr(tag,name){return exactDecode(tag.match(new RegExp('\\b'+name+'=["\x27]([^"\x27]*)["\x27]','i'))?.[1]||'');}
function exactDiv(block,cls){
 const re=/<div\b[^>]*>/gi;let m;
 while((m=re.exec(block))){if(!exactAttr(m[0],'class').split(/\s+/).includes(cls))continue;
  const rest=block.slice(re.lastIndex);let depth=1;
  for(const tag of rest.matchAll(/<\/?div\b[^>]*>/gi)){depth+=/^<\//.test(tag[0])?-1:1;if(depth===0)return rest.slice(0,tag.index);}
  return '';
 }return '';
}
function exactRich(raw){
 let text='';const entities=[],stack=[];
 const add=(type,offset,length,extra={})=>{if(length>0)entities.push({type,offset,length,...extra});};
 for(const token of String(raw||'').match(/<[^>]*>|[^<]+/g)||[]){
  if(token[0]!=='<'){text+=exactDecode(token);continue;}
  const m=token.match(/^<(\/?)\s*([a-z0-9-]+)/i);if(!m)continue;
  const closing=Boolean(m[1]),name=m[2].toLowerCase();
  if(name==='br'){text+='\n';continue;}
  if(name==='img'){text+=exactAttr(token,'alt');continue;}
  if(closing){
   let i=stack.length-1;while(i>=0&&stack[i].name!==name)i--;
   if(i>=0){const open=stack.splice(i,1)[0];if(open.type)add(open.type,open.offset,text.length-open.offset,open.extra);}
   if(name==='p'&&!text.endsWith('\n'))text+='\n';continue;
  }
  let type=null,extra={};const cls=exactAttr(token,'class');
  const inEmoji=stack.some(x=>x.name==='tg-emoji');
  if(name==='tg-emoji'){const id=exactAttr(token,'emoji-id');if(/^\d+$/.test(id)){type='custom_emoji';extra={custom_emoji_id:id};}}
  else if(!inEmoji){
   if(['b','strong'].includes(name))type='bold';
   if(['i','em'].includes(name)&&!cls.split(/\s+/).includes('emoji'))type='italic';
   if(['u','ins'].includes(name))type='underline';
   if(['s','del','strike'].includes(name))type='strikethrough';
   if(name==='code')type=stack.some(x=>x.name==='pre')?null:'code';
   if(name==='pre')type='pre';
   if(name==='blockquote')type='blockquote';
   if(name==='tg-spoiler'||cls.split(/\s+/).some(c=>['tg-spoiler','tgme_widget_message_spoiler'].includes(c)))type='spoiler';
   if(name==='a'){const url=exactAttr(token,'href');if(/^(https?:\/\/|tg:\/\/)/i.test(url)){type='text_link';extra={url};}}
  }
  if(!/\/$/.test(token.slice(0,-1)))stack.push({name,type,offset:text.length,extra});
 }
 for(const open of stack)if(open.type)add(open.type,open.offset,text.length-open.offset,open.extra);
 // Сохраняем переносы строк и отступы источника; смещения считаются в UTF-16.
 return {text,entities:entities.sort((a,b)=>a.offset-b.offset||b.length-a.length)};
}
function odessaParseSource(html){
 if(html.length>5000000)throw Error('Страница слишком большая');const found=new Map();
 for(const block of html.split(/(?=<div\b[^>]*data-post=")/)){
  const post=block.match(new RegExp('data-post=\"'+CHANNEL+'\\/(\\d+)\"'));if(!post)continue;
  const raw=exactDiv(block,'js-message_text'),rich=exactRich(raw);
  const stamp=block.match(/<time\b[^>]*datetime="([^"]+)"/)?.[1];
  const {media,unsupported}=exactMedia(block);
  const images=media.filter(x=>x.type==='photo').map(x=>x.url);
  let replyId=null;for(const a of block.matchAll(/<a\b[^>]*>/gi)){if(!exactAttr(a[0],'class').split(/\s+/).includes('tgme_widget_message_reply'))continue;const id=exactAttr(a[0],'href').match(new RegExp('(?:https?:\\/\\/t\\.me\\/)?(?:s\\/)?'+CHANNEL+'\\/(\\d+)(?:[?#]|$)'))?.[1];if(id)replyId=Number(id);break;}
  const replyText=exactRich(exactDiv(block,'tgme_widget_message_reply_text')).text;
  const item={id:Number(post[1]),date:Date.parse(stamp||''),...rich,replyId,replyText,images,media,unsupported};
  const old=found.get(item.id);if(old){item.images=[...new Set([...old.images,...item.images])];if(!item.text){item.text=old.text;item.entities=old.entities;}item.media=[...new Map([...old.media,...item.media].map(x=>[x.url,x])).values()];item.unsupported ||=old.unsupported;}
  found.set(item.id,item);
 }
 const items=[...found.values()].sort((a,b)=>a.id-b.id);
 if(!items.length||items.some(x=>!Number.isFinite(x.date)))throw Error('Не удалось прочитать канал тревог и время сообщений');return items;
}

export function skipCollection(text) {
  const t=String(text||'').replace(/[\u200B-\u200D\uFEFF]/g,' ');

  return /(?:monobank\.ua|privat24|paypal|банка|банку|збір|сбор|донат|реквізит)/i.test(t)
    || /(?:реклам|розіграш|розыгрыш|підписуй|подписыв|промокод|ваканс|продам|куплю)/i.test(t)
    || /(?:опитуван|опрос|питання|вопрос|підкажіть|подскажите|ваша думка|ваше мнение)/i.test(t)
    || /(?:новин|новост|дтп|поліці|полици|суд|затриман|задержан|загин|погиб|поранен|наслідк|последств|пошкоджен|поврежден)/i.test(t);
}

export function isAlertPost(text) {
 return radarOperational(text);
}

// ODESSA_SOURCE_EMOJI_V1
function odessaMarkEmoji(raw){
 return String(raw||'').replace(/<tg-emoji\b[^>]*emoji-id=["'](\d+)["'][^>]*>([\s\S]*?)<\/tg-emoji>/gi,(_,id,inner)=>'\uE000'+id+'\uE001'+decode(inner)+'\uE002');
}
function odessaFinishEmoji(marked){
 const entities=[];let text='',last=0;
 for(const m of marked.matchAll(/\uE000(\d+)\uE001([^\uE002]*)\uE002/g)){
  text+=marked.slice(last,m.index);const offset=text.length;text+=m[2];
  if(m[2])entities.push({type:'custom_emoji',offset,length:m[2].length,custom_emoji_id:m[1]});
  last=m.index+m[0].length;
 }
 text+=marked.slice(last);return {text,entities};
}


function cleanAlertText(text=''){
 return String(text||'')
  .replace(/[\u200B-\u200D\uFEFF]/g,'')
  .replace(/\r/g,'')
  .split('\n')
  .map(line=>line
   .replace(/https?:\/\/\S+|t\.me\/\S+|@[a-z0-9_]{3,}/gi,'')
   .replace(/[ \t]+/g,' ')
   .trim())
  .filter(Boolean)
  .filter(line=>!/(підписат|подписат|підписуй|подписыв|канал\s+по\s+тривог|канал\s+по\s+тревог|наша\s+інста|наша\s+инста|написати\s+нам|написать\s+нам|ссылка\s+на\s+нас|посилання\s+на\s+нас|реклам|співпрац|сотрудничеств|boost|premium)/i.test(line))
  .join('\n')
  .replace(/\n{3,}/g,'\n\n')
  .trim();
}

// ODESSA_KNOWN_TYPO_FIX_V1
function odessaCorrectKnownTypo(text){
 return String(text||'').replace(/(?<![\p{L}])обласли(?![\p{L}])/giu,word=>word===word.toUpperCase()?'ОБЛАСТИ':word[0]===word[0].toUpperCase()?'Области':'области');
}
export function parse(html){
 const items=odessaParseSource(html);
 for(const item of items){
  const before=item.text;
  item.text=odessaCorrectKnownTypo(cleanAlertText(item.text));
  item.replyText=odessaCorrectKnownTypo(cleanAlertText(item.replyText));
  // Никогда не переносим скрытые ссылки источника в нашу группу.
  if(item.text!==before)item.entities=[];
  else item.entities=(item.entities||[]).filter(e=>e.type!=='text_link');
 }
 return items;
}

// ODESSA_LIVE_MEDIA_V1
function exactMedia(block){
 const media=[],seen=new Set();let unavailable=false;
 function add(type,value,index){const url=safePhoto(exactDecode(value));if(!url){unavailable=true;return;}if(!seen.has(url)){seen.add(url);media.push({type,url,index});}}
 // Restrict photo extraction to actual photo wrappers: video posters and reply thumbnails are excluded.
 for(const m of block.matchAll(/<(?:a|div)\b[^>]*>/gi)){
  if(!exactAttr(m[0],'class').split(/\s+/).includes('tgme_widget_message_photo_wrap'))continue;
  const url=m[0].match(/background-image:\s*url\(['"]?([^'")]+)['"]?\)/i)?.[1];if(url)add('photo',url,m.index);else unavailable=true;
 }
 let videos=0;
 for(const m of block.matchAll(/<video\b[^>]*>[\s\S]*?<\/video>/gi)){
  videos++;const opening=m[0].match(/^<video\b[^>]*>/i)[0];let src=exactAttr(opening,'src');
  if(!src){for(const tag of m[0].matchAll(/<source\b[^>]*>/gi)){src=exactAttr(tag[0],'src');if(src)break;}}
  if(src)add('video',src,m.index);else unavailable=true;
 }
 if(/tgme_widget_message_video_player/.test(block)&&!videos)unavailable=true;
 if(/tgme_widget_message_(?:document|voice|sticker|poll)|tgme_widget_message_media_not_supported/.test(block))unavailable=true;
 return {media:media.sort((a,b)=>a.index-b.index).map(({type,url})=>({type,url})),unsupported:unavailable};
}
