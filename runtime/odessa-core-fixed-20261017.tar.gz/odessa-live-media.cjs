const fs=require('fs'),path=require('path');
exports.create=(root,parse,channel='odessagolovna')=>{
 const safeChannel=String(channel||'odessagolovna').replace(/[^a-zA-Z0-9_]/g,'');
 const file=path.join(root,'odessa-live-media-pending-'+safeChannel+'.json');
 function read(){try{return JSON.parse(fs.readFileSync(file,'utf8'));}catch{return [];}}
 function save(q){fs.writeFileSync(file+'.tmp',JSON.stringify(q));fs.renameSync(file+'.tmp',file);}
 return {
  async hydrate(item){
   if(!item.unsupported)return item;
   try{
    const r=await fetch('https://t.me/'+safeChannel+'/'+item.id+'?embed=1&mode=tme',{signal:AbortSignal.timeout(20000)});
    if(!r.ok)return item;
    const resolved=parse(await r.text()).find(x=>x.id===item.id);
    if(resolved&&!resolved.unsupported)return {...item,media:resolved.media,images:resolved.images,unsupported:false};
   }catch{}
   return item;
  },
  pending(item,error){const q=read();if(!q.some(x=>x.id===item.id)){q.push({...item,queuedAt:Date.now(),reason:String(error).slice(0,400)});save(q);}console.error('RADAR_MEDIA_PENDING',item.id,String(error).slice(0,300),'Файл не опубликован; сохранён для проверки.');}
 };
};
